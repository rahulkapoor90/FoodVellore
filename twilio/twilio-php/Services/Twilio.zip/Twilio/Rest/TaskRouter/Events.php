<?php

class Services_Twilio_Rest_TaskRouter_Events extends Services_Twilio_TaskRouterListResource {

}
